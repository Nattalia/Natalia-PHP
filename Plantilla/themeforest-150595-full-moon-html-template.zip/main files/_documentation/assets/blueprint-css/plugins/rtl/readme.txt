RTL
* Mirrors Blueprint, so it can be used with Right-to-Left languages.

By Ran Yaniv Hartstein, ranh.co.il

Usage
----------------------------------------------------------------

1) Add this line to your HTML:
   <link rel="stylesheet" href="css/blueprint/plugins/rtl/screen.css" type="text/css" media="screen, projection">	